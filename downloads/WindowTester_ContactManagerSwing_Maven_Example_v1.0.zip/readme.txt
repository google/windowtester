WindowTester Pro - ContactManager - Swing - Maven example
=========================================================

This is a small example that shows how to use Maven to
build a Swing application and run WindowTester Pro
UI tests with the Maven Surefire Plugin.

Tested on Win32 and Linux x86 GTK with Maven 3.0.4

This example can easily be adapted for other platforms.

Requirements:
Maven 3.x.x (http://maven.apache.org/download.cgi)

To build and run UI tests:
1. cd com.windowtester.example.contactmanager.swing_parent
2. mvn clean verify

To skip the UI tests:
  mvn clean verify -DskipTests


Please note:
In order to keep this example short and simple a few shortcuts have been used:
-Using system scope dependencies (com.windowtester.runtime and com.windowtester.swing.runtime)
and referencing JARs is generally NOT recommended. Both plugins should be build as 
pure maven plugins and specified as dependencies in the pom.xml of
com.windowtester.example.contactmanager.swing_test.
-The groupIds, artifactIds and versions of the Eclipse plugins
(org.eclipse.runtime.core, org.eclipse.equinox.common, org.eclipse.jface)
were just picked, because they existed in the Maven Central repository.
In a productive environment these plugins would also need to be build
with pure maven.
