package abbot.tester;

/** Hierarchy placeholder for Container.  Provides no additional user
 * actions.
 */ 
public class ContainerTester extends ComponentTester {
}
