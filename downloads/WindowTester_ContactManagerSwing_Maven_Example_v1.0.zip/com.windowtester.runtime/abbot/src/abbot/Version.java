package abbot;

/** Current version of the framework. */

public interface Version {
    String VERSION = "1.0.0rc1";
}






