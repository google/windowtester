/*******************************************************************************
 *  Copyright (c) 2012 Google, Inc.
 *  All rights reserved. This program and the accompanying materials
 *  are made available under the terms of the Eclipse Public License v1.0
 *  which accompanies this distribution, and is available at
 *  http://www.eclipse.org/legal/epl-v10.html
 *  
 *  Contributors:
 *  Google, Inc. - initial API and implementation
 *******************************************************************************/
package com.windowtester.runtime.condition;

import com.windowtester.runtime.IUIContext;

/**
 * Implementers define a condition to test and an associated handler that handles the condition 
 * in the event that it evaluates to <code>true</code>.  <code>IUIConditionHandler</code>s behave
 * like {@link IConditionHandler}s but instead of using the {@link ICondition#test()} method to 
 * test a condition, the {@link IUICondition#testUI(IUIContext)} is used instead.
 *
 * <p/>
 * Note that conditions should be designed to <em>test</em> and not to <em>modify</em>
 * the User Interface.
 * <p/>
 * @see IConditionHandler
 */
public interface IUIConditionHandler
	extends IConditionHandler, IUICondition
{

}
