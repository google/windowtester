WindowTester Pro - ContactManagerRCP - Tycho example
====================================================

This is a small example that shows how to use Tycho to
build an Eclipse RCP application and run WindowTester Pro
UI tests with the Tycho Surefire Plugin.

Supported platforms: Win32, Linux x86 GTK
Eclipse platform: 3.7x

This example can easily be adapted for other platforms
and Eclipse versions.

Requirements:
Maven 3.x.x (http://maven.apache.org/download.cgi)

To build and run UI tests:
1. cd com.windowtester.example.contactmanager.rcp_parent
2. mvn clean verify

To skip the UI tests:
  mvn clean verify -DskipTests


Release notes:

v1.1:
-fixed issue with missing dependencies by using the WindowTester
 P2 repository in the parent pom.xml instead of the test plugin
 pom.xml

v1.0:
-initial release



If you have any questions or comments regarding this example,
please ask them in the official WindowTester Google Group:
  http://groups.google.com/group/windowtester-pro