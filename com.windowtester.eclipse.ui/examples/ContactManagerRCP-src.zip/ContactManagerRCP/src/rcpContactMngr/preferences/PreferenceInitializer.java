package rcpContactMngr.preferences;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

import rcpContactMngr.RcpContactMngrPlugin;

/**
 * Class used to initialize default preference values.
 */
public class PreferenceInitializer extends AbstractPreferenceInitializer {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer#initializeDefaultPreferences()
	 */
	public void initializeDefaultPreferences() {
		IPreferenceStore store = RcpContactMngrPlugin.getDefault()
				.getPreferenceStore();
		store.setDefault(PreferenceConstants.CONTACTS_DISPLAY_BY__FIRST_NAME, "1");
		store.setDefault(PreferenceConstants.CONTACTS_DEFAULT_PHONE_AREA_CODE,
				"951");
	}

}
