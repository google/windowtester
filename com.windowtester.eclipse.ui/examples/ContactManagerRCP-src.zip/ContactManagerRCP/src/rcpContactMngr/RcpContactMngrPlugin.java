package rcpContactMngr;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

import rcpContactMngr.model.Contact;
import rcpContactMngr.model.ContactsManager;

/**
 * The main plugin class to be used in the desktop.
 */
public class RcpContactMngrPlugin extends AbstractUIPlugin {

	//The shared instance.
	private static RcpContactMngrPlugin plugin;
	
	/**
	 * The constructor.
	 */
	public RcpContactMngrPlugin() {
		plugin = this;
	}

	/**
	 * This method is called upon plug-in activation
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
	}

	/**
	 * This method is called when the plug-in is stopped
	 */
	public void stop(BundleContext context) throws Exception {
		ContactsManager.getManager().saveContacts();
		Contact.disposeColors();
		super.stop(context);
		plugin = null;
	}

	/**
	 * Returns the shared instance.
	 */
	public static RcpContactMngrPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns an image descriptor for the image file at the given
	 * plug-in relative path.
	 *
	 * @param path the path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return AbstractUIPlugin.imageDescriptorFromPlugin("testRcp", path);
	}
}
