package rcpContactMngr.model;

public interface ContactsManagerListener
{
	 public void contactsChanged(ContactsManagerEvent event);
}
