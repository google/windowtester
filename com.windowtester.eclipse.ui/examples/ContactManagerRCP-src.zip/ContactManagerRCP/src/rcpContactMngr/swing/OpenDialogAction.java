package rcpContactMngr.swing;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.ui.IWorkbenchWindow;



public class OpenDialogAction extends Action {

	private final IWorkbenchWindow window;
	
	
	public OpenDialogAction(IWorkbenchWindow window, String label) {
		this.window = window;
        setText(label);
//      The id is used to refer to the action in a menu or toolbar
		setId("swing.dialog");
       }
	
	public void run() {
		NewContactDialog dialog = new NewContactDialog();
		dialog.setVisible(true);
	}
	
}
