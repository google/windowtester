package rcpContactMngr.swing;

import javax.swing.JDialog;

import org.eclipse.swt.widgets.Display;

public class NewContactDialog extends JDialog {
  
	
	public NewContactDialog() {  
		super();
		setTitle("New Contact");
		Display display = Display.getCurrent();
		ContactEditor contactEditor = new ContactEditor(display,true);
	//	contactEditor.setOpaque(true);
		setContentPane(contactEditor);
		pack();
		setVisible(true);
  }

 
}
           