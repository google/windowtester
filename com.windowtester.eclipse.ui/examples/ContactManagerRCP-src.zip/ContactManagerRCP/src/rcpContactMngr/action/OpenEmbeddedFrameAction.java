package rcpContactMngr.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchWindow;

import rcpContactMngr.wizards.EmbeddedSwingFrameWizard;

public class OpenEmbeddedFrameAction extends Action {
	
	private final IWorkbenchWindow window;
	
	
	public OpenEmbeddedFrameAction(IWorkbenchWindow window, String label) {
		this.window = window;
        setText(label);
//      The id is used to refer to the action in a menu or toolbar
		setId("rcpContactsMngr.EmbeddedFrame");
	//	setImageDescriptor(rcpContactMngr.RcpContactMngrPlugin.getImageDescriptor("/icons/sample.gif"));
	}
	
	
	public void run() {
		EmbeddedSwingFrameWizard wizard = new EmbeddedSwingFrameWizard();
		Shell shell = window.getShell();
		WizardDialog dialog =
			new WizardDialog(window.getShell(),wizard);
		dialog.open();
	}

}
