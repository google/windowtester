package rcpContactMngr.wizards;

import org.eclipse.jface.wizard.Wizard;

public class EmbeddedSwingFrameWizard extends Wizard {

	private EmbeddedSwingFramePage page;
	
	public EmbeddedSwingFrameWizard(){
		super();
	}
	
	public void addPages(){
		page = new EmbeddedSwingFramePage();
		addPage(page);
	}
	
	 public boolean canFinish() {
		 return (page.isPageComplete());
	//	 return true;
	  }
	
	public boolean performFinish() {
		page.createContact();
		return true;
	}

}
