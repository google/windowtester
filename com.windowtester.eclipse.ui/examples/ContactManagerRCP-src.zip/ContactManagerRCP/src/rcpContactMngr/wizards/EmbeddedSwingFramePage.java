package rcpContactMngr.wizards;

import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Panel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;

import rcpContactMngr.model.Contact;
import rcpContactMngr.model.ContactsManager;
import rcpContactMngr.swing.ContactEditor;

public class EmbeddedSwingFramePage extends WizardPage {

	
	private Display display;
	private ContactEditor cEditor;
	private Contact contact;
	
	
	protected EmbeddedSwingFramePage() {
		super("wizardPage");
		setTitle("New Contact");
		setDescription("Enter information for new contact\nThis page contains an embedded AWT frame");
		setPageComplete(false);
		display = Display.getCurrent();
	}

	public void createControl(Composite parent) {
		final Composite composite = new Composite(parent, SWT.EMBEDDED);
		composite.setLayout(new FillLayout());

		final Frame frame = SWT_AWT.new_Frame(composite);	
		contact = new Contact("", "", "");
		//final Panel panel = createPanel();
		final ContactEditor contactEditor = new ContactEditor(contact,false);
		cEditor = contactEditor;
		contactEditor.getLastNameText().addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				display.asyncExec(new Runnable() {
			        public void run() {
			            setPageComplete(true);
			          }
			        });
			}
		});
		
	//	frame.add(panel);
		frame.add(contactEditor);
		frame.addWindowListener( new WindowAdapter() {
		    public void windowActivated( WindowEvent e ){
		         contactEditor.getFirstNameText().requestFocus();
		      }
		} );
		
		frame.pack();
		frame.setVisible(true);
	
		setControl(composite);
		
	}
	
	

	public void createContact(){
		Contact contact = new Contact(cEditor.getLastNameText().getText(),cEditor.getFirstNameText().getText(),cEditor.getHomeText().getText());
		contact.setAddress(cEditor.getStreetText().getText(),cEditor.getCityText().getText(),
						   cEditor.getStateText().getText(),cEditor.getZipText().getText());
		contact.setEmail(cEditor.getEmailText().getText());
		contact.setMobilePh(cEditor.getMobileText().getText());
		contact.setOfficePh(cEditor.getOfficeText().getText());
		ContactsManager mgr = ContactsManager.getManager();
		mgr.newContact(contact);
		
	}
	

}
