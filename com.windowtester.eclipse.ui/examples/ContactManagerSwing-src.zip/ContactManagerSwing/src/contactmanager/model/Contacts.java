package contactmanager.model;

import java.util.ArrayList;

public class Contacts
{

	static ArrayList contacts = new ArrayList();
	
	public static void addContact(Contact contact) {
		contacts.add(contact);
	}

	public static ArrayList getContacts() {
		return contacts;
	}

}
