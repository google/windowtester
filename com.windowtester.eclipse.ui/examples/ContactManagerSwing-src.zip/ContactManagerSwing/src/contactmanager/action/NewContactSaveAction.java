package contactmanager.action;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import contactmanager.ContactManagerSwing;
import contactmanager.editor.ContactEditor;

/**
 * Action to finish the prompt for new contact process
 * <p>
 * Copyright (c) 2006, Instantiations, Inc.<br>
 * All Rights Reserved
 * 
 * @author Leman Reagan
 */
public class NewContactSaveAction
	implements ActionListener
{
	public void actionPerformed(ActionEvent e) {
		JButton jButton = (JButton) e.getSource();
		ContactEditor ce = (ContactEditor) jButton.getParent();
		ContactManagerSwing.getInstance().refreshList();
		ce.getParent().getParent().getParent().setVisible(false);
	}
}