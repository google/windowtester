package com.windowtester.swt.test.sample;

import junit.extensions.UITestCaseSWT;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;

import com.windowtester.runtime.IUIContext;
import com.windowtester.runtime.condition.ICondition;
import com.windowtester.runtime.swt.condition.shell.ShellDisposedCondition;
import com.windowtester.runtime.swt.condition.shell.ShellShowingCondition;
import com.windowtester.runtime.swt.locator.ButtonLocator;
import com.windowtester.runtime.swt.locator.MenuItemLocator;
import com.windowtester.runtime.swt.locator.TreeItemLocator;

/**
 * A sample UI test that excercises  project creation in the Eclipse UI.
 * <p>
 * For Eclipse 3.2
 * <p>
 * To run, launch using a standard Eclipse JUnit Plug-in Test Launch
 * Configuration (Run As > JUnit Plug-in Test).
 * <p>
 * Copyright (c) 2006, Instantiations, Inc.<br>
 * All Rights Reserved
 * 
 */

public class EclipseTest extends UITestCaseSWT {


	////////////////////////////////////////////////////////////////////
	//
	// Sample Tests
	//
	////////////////////////////////////////////////////////////////////
	
	/**
	 * A test that creates a new project and verifies that it exists 
	 * in the workspace.
	 * @throws Exception 
	 */
	public void testSimpleProjectCreation() throws Exception {
		
		String testProjectName = getClass().getName() + ".SimpleProject1";
		//create the project
		createSimpleProject(testProjectName);
		//verify it exists
		assertProjectExists(testProjectName);	
		
	}
	
	/**
	 * A test that creates a new Java project and verifies that it exists 
	 * in the workspace.
	 * @throws Exception 
	 */
	public void testJavaProjectCreation() throws Exception {
		
		String testProjectName = getClass().getName() + ".JavaProject1";
		
		//create the project
		createJavaProject(testProjectName);
		
		//verify it exists
		assertProjectExists(testProjectName);	
	}

	

	////////////////////////////////////////////////////////////////////
	//
	// Test Helper/Macros
	//
	////////////////////////////////////////////////////////////////////
	
	/**
	 * Create a simple project with the given name.
	 */
	public void createSimpleProject(String projectName) throws Exception {
		
		IUIContext ui = getUI();
		ui.click(new MenuItemLocator("&File/&New\tAlt+Shift+N/P&roject..."));
		ui.wait(new ShellShowingCondition("New Project"));
		ui.click(new TreeItemLocator("General/Project"));
		ui.click(new ButtonLocator("&Next >"));
		ui.enterText(projectName);
		ui.click(new ButtonLocator("&Finish"));
		ui.wait(new ShellDisposedCondition("project.creation.dialog"));
		//wait for the project to be created
		waitForProject(projectName);
		
	}
	
	
	/**
	 * Create a Java project with the given name.
	 */
	public void createJavaProject(String projectName) throws Exception {
		
		IUIContext ui = getUI();
		ui.click(new MenuItemLocator("&File/&New\tAlt+Shift+N/P&roject..."));
		ui.wait(new ShellShowingCondition("New Project"));
		ui.click(new TreeItemLocator("Java/Java Project"));
		ui.click(new ButtonLocator("&Next >"));
		ui.enterText(projectName);
		ui.click(new ButtonLocator("&Finish"));
		ui.wait(new ShellDisposedCondition("project.creation.dialog"));
		//wait for the project to be created
		waitForProject(projectName);
	}
	
	////////////////////////////////////////////////////////////////////
	//
	// Assertion Helpers
	//
	////////////////////////////////////////////////////////////////////
	
	
	
	/**
	 * Assert that a project exists with the given name.
	 */
	public static void assertProjectExists(String projectName) {
        IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
        IProject project = root.getProject(projectName);
        assertTrue(project.exists());
	}	
	
	
	////////////////////////////////////////////////////////////////////
	//
	// Wait for Condition Helpers
	//
	////////////////////////////////////////////////////////////////////
	
	/**
	 * Wait for a project with the given name to show up in the file system.
	 */
	public void waitForProject(String projectName) {
		getUI().wait(new ProjectExistsCondition(projectName, true), 45000,
				2500);
	}
	
	////////////////////////////////////////////////////////////////////
	//
	// Helper Conditions
	//
	////////////////////////////////////////////////////////////////////
	
	
	/**
	 * A condition that tests for project existence.
	 */	
	public static class ProjectExistsCondition implements ICondition {
	    private final IProject _iproject;
	    private final boolean _exists;

	    public ProjectExistsCondition(String projectName, boolean exists) {
	        assertNotNull(projectName);
	        
	        IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
	        assertNotNull(root);
	        
	        _iproject = root.getProject(projectName);
	        _exists = exists;
	    }
	    
		public ProjectExistsCondition(IProject project, boolean exists) {
	        assertNotNull(project);
	        
	        _iproject = project;
	        _exists = exists;
	    }

	    /**
	     * @see com.windowtester.runtime.condition.ICondition#test()
	     */
	    public boolean test() {
	        return _exists == _iproject.exists();
	    }
	}
	

}