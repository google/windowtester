package com.instantiations.contactmanager;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

import com.instantiations.contactmanager.model.Contact;
import com.instantiations.contactmanager.model.ContactsManager;

/**
 * The main plugin class to be used in the desktop.
 */
public class ContactmanagerPlugin extends AbstractUIPlugin {

	//The shared instance.
	private static ContactmanagerPlugin plugin;
	
	/**
	 * The constructor.
	 */
	public ContactmanagerPlugin() {
		plugin = this;
	}

	/**
	 * This method is called upon plug-in activation
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
	}

	/**
	 * This method is called when the plug-in is stopped
	 */
	public void stop(BundleContext context) throws Exception {
		ContactsManager.getManager().saveContacts();
		Contact.disposeColors();
		super.stop(context);
		plugin = null;
	}

	/**
	 * Returns the shared instance.
	 */
	public static ContactmanagerPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns an image descriptor for the image file at the given
	 * plug-in relative path.
	 *
	 * @param path the path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return AbstractUIPlugin.imageDescriptorFromPlugin("testRcp", path);
	}
}
