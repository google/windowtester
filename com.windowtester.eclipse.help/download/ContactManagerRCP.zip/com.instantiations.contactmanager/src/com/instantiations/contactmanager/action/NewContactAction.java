package com.instantiations.contactmanager.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.ui.IWorkbenchWindow;

import com.instantiations.contactmanager.wizards.NewContactWizard;


public class NewContactAction extends Action
{
	private final IWorkbenchWindow window;
	
	public NewContactAction(IWorkbenchWindow window, String label) {
		this.window = window;
        setText(label);
//      The id is used to refer to the action in a menu or toolbar
		setId("rcpContactsMngr.NewContact");
        // Associate the action with a pre-defined command, to allow key bindings.
//		setActionDefinitionId("rcpContactsMngr.NewContact");
		setImageDescriptor(com.instantiations.contactmanager.ContactmanagerPlugin.getImageDescriptor("/icons/sample.gif"));
	}
	
	public void run() {
		NewContactWizard wizard = new NewContactWizard();
		WizardDialog dialog =
			new WizardDialog(window.getShell(),wizard);
		dialog.open();
	}
}
