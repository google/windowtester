package com.instantiations.contactmanager.model;

import java.util.EventObject;


public class ContactsManagerEvent extends EventObject
{
    private static final long serialVersionUID = 5516075349620653480L;
	private final IContact[] added;
	private final IContact[] removed;

	   public ContactsManagerEvent(
	      ContactsManager source,
	      IContact[] contactsAdded,
	      IContact[] contactsRemoved) {
	         
	      super(source);
	      added = contactsAdded;
	      removed = contactsRemoved;
	   }
	   
	   public IContact[] getContactsAdded() {
	      return added;
	   }
	   
	   public IContact[] getContactsRemoved() {
	      return removed;
	   }

}
