package com.instantiations.contactmanager.model;

public interface ContactsManagerListener
{
	 public void contactsChanged(ContactsManagerEvent event);
}
