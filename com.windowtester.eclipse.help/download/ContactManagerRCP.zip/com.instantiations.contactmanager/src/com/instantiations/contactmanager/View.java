package com.instantiations.contactmanager;

import org.eclipse.core.runtime.Preferences.IPropertyChangeListener;
import org.eclipse.core.runtime.Preferences.PropertyChangeEvent;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.window.IShellProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;
import org.eclipse.ui.dialogs.PropertyDialogAction;
import org.eclipse.ui.part.ViewPart;

import com.instantiations.contactmanager.action.CopyContactAction;
import com.instantiations.contactmanager.action.CutContactAction;
import com.instantiations.contactmanager.action.DeleteAction;
import com.instantiations.contactmanager.action.NewContactAction;
import com.instantiations.contactmanager.action.PasteContactAction;
import com.instantiations.contactmanager.editor.ContactEditorInput;
import com.instantiations.contactmanager.editor.ContactsEditor;
import com.instantiations.contactmanager.model.Contact;
import com.instantiations.contactmanager.model.ContactsManager;
import com.instantiations.contactmanager.preferences.PreferenceConstants;


public class View extends ViewPart {
	public static final String ID = "rcpContactMngr.view";

	private TableViewer viewer;
	private CopyContactAction copyAction;
	private CutContactAction cutAction;
	private PasteContactAction pasteAction;
	private DeleteAction removeAction;
	private NewContactAction newContactAction;
	private IWorkbenchAction copyWAction;
	private IWorkbenchAction cutWAction;
	private IWorkbenchAction pasteWAction;
	private IWorkbenchAction deleteAction;
	
	
	private final IPropertyChangeListener propertyChangeListener
	= new IPropertyChangeListener(){
		public void propertyChange(PropertyChangeEvent event){
			if (event.getProperty().equals(
				PreferenceConstants.CONTACTS_DISPLAY_BY__FIRST_NAME))
				viewer.refresh();
		}
};
	

	class ViewLabelProvider extends LabelProvider implements
			ITableLabelProvider {
		public String getColumnText(Object obj, int index) {
			return getText(obj);
		}

		public Image getColumnImage(Object obj, int index) {
			return getImage(obj);
		}

		public Image getImage(Object obj) {
			return PlatformUI.getWorkbench().getSharedImages().getImage(
					ISharedImages.IMG_OBJ_ELEMENT);
		}
	}

	public View(){
	};
	
	/**
	 * This is a callback that will allow us to create the viewer and initialize
	 * it.
	 */
	public void createPartControl(Composite parent) {
		viewer = new TableViewer(parent, SWT.MULTI | SWT.H_SCROLL
				| SWT.V_SCROLL);
		viewer.setContentProvider(new ContactsViewContentProvider());
		viewer.setLabelProvider(new ViewLabelProvider());
		viewer.setInput(ContactsManager.getManager());
		getSite().setSelectionProvider(viewer);
		viewer.addDoubleClickListener(new IDoubleClickListener(){
			public void doubleClick(org.eclipse.jface.viewers.DoubleClickEvent event){
				try {
					Contact c = null;
					try {
						c = (Contact)((StructuredSelection)event.getSelection()).getFirstElement();
					} catch(Exception e){
						e.printStackTrace();
						c = null;
					}
					IEditorInput input = new ContactEditorInput(c);
					getViewSite().getWorkbenchWindow().getActivePage().openEditor(input,ContactsEditor.ID);
				}catch (Throwable e){
					e.printStackTrace();
				}
				
			}
		});
		createActions();
		createContextMenu();
		hookGlobalActions();
		
		ContactmanagerPlugin
			.getDefault()
			.getPluginPreferences()
			.addPropertyChangeListener(propertyChangeListener);
		
	}

	/**
	 *  Create the actions for the view
	 */
	private void createActions(){
		
		copyAction = new CopyContactAction(this,"Copy");
		removeAction = new DeleteAction(getSite().getWorkbenchWindow(),"Delete");
		cutAction = new CutContactAction(copyAction,removeAction,"Cut");
				
		pasteAction = new PasteContactAction(this,"Paste");
		newContactAction = new NewContactAction(
				getSite().getWorkbenchWindow(),"New Contact..."); 
		copyWAction = ActionFactory.COPY.create(getSite().getWorkbenchWindow());
		cutWAction = ActionFactory.CUT.create(getSite().getWorkbenchWindow());
		pasteWAction = ActionFactory.PASTE.create(getSite().getWorkbenchWindow());
		deleteAction = ActionFactory.DELETE.create(getSite().getWorkbenchWindow());
	
	}

	/***
	 * 
	 */
	private void createContextMenu(){
		MenuManager menuMgr = new MenuManager("#PopupMenu");
		menuMgr.setRemoveAllWhenShown(true);
		menuMgr.addMenuListener(new IMenuListener(){
			public void menuAboutToShow(IMenuManager m){
				View.this.fillContextMenu(m);
			}
		});
		Menu menu =
			menuMgr.createContextMenu(viewer.getControl());
		viewer.getControl().setMenu(menu);
		getSite().registerContextMenu(menuMgr,viewer);
	}
	
	private void fillContextMenu(IMenuManager menuMgr){
		menuMgr.add(
			new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
		menuMgr.add(new Separator());	
		menuMgr.add(newContactAction);
		menuMgr.add(new Separator());	
		menuMgr.add(cutWAction);
		menuMgr.add(copyWAction);
		menuMgr.add(pasteWAction);
		menuMgr.add(new Separator());
		menuMgr.add(deleteAction);
		menuMgr.add(new Separator());
		menuMgr.add(
			new PropertyDialogAction(
				(IShellProvider)this.getViewSite(),viewer));	
		
	}
	
	
	/**
	 *  hook the global cut, copy etc
	 */
	protected void hookGlobalActions(){
		
		getViewSite().getActionBars().setGlobalActionHandler(
				ActionFactory.DELETE.getId(),
				removeAction);
		getViewSite().getActionBars().setGlobalActionHandler(
				ActionFactory.COPY.getId(),copyAction);
		getViewSite().getActionBars().setGlobalActionHandler(
				ActionFactory.CUT.getId(),cutAction);
		getViewSite().getActionBars().setGlobalActionHandler(
				ActionFactory.PASTE.getId(),pasteAction);	
	
	}
	
	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {
		viewer.getControl().setFocus();
	}
}