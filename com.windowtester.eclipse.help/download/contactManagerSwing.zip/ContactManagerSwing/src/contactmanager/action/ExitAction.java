package contactmanager.action;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Action to exit the application.
 * <p>
 * Copyright (c) 2006, Instantiations, Inc.<br>
 * All Rights Reserved
 *
 * @author Leman Reagan
 */
public class ExitAction	implements ActionListener
{
	public void actionPerformed(ActionEvent e) {
		Component c = (Component)e.getSource();
		System.exit(0);
	}
}