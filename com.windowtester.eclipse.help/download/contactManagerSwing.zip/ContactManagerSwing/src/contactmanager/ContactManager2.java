package contactmanager;

import java.awt.AWTEvent;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.AWTEventListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;

import contactmanager.action.CreateContactAction;
import contactmanager.action.ExitAction;
import contactmanager.editor.ContactEditor;
import contactmanager.model.Contact;
import contactmanager.model.Contacts;

public class ContactManager2 extends JFrame implements ActionListener {

	/**
	 * Singleton
	 */
	private static ContactManager2 instance;

	/**
	 * Answer the single instance of the Contact Manager
	 * 
	 * @return the instance (not <code>null</code>)
	 */
	public static ContactManager2 getInstance() {
		if (instance == null)
			instance = new ContactManager2("Contact Manager");
		return instance;
	}

	/**
	 * The list of contact that appears on the left side of the contact manager window
	 */
	private final JList list = new JList();

	/**
	 * Panel appearing on the right side of the contact manager window in which the
	 * contact "editors" appear showing detailed information for each selected contact.
	 */
	private final JTabbedPane tabbedPane = new JTabbedPane();

	public static void main(String[] args)
    {
        ContactManager2 cm = getInstance();
        cm.pack();
        cm.setVisible(true);
    } 
	
	/**
	 * Construct a new initialized instance
	 */
	private ContactManager2(String title) {
		super(title);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new GridBagLayout());

		final JSplitPane splitPane = new JSplitPane();
		final GridBagConstraints gridBagConstraints = new GridBagConstraints();
		gridBagConstraints.ipady = 335;
		gridBagConstraints.ipadx = 300;
		getContentPane().add(splitPane, gridBagConstraints);

		splitPane.setRightComponent(tabbedPane);

		final JPanel listPanel = new JPanel();
		listPanel.setLayout(new FlowLayout());
		listPanel.setPreferredSize(new Dimension(160, 0));
		splitPane.setLeftComponent(listPanel);
		
		listPanel.add(list);

		loadContacts();
		refreshList();

		list.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2)
					openContactEditor();
			}
		});
		list.setPreferredSize(new Dimension(150, 330));
		JMenuBar menuBar = createMenuBar();
		setJMenuBar(menuBar);
		
//      AWTEventListener
        getToolkit().addAWTEventListener(
          new AWTEventListener() {
            public void eventDispatched(AWTEvent e) {
              System.out.println(e+"\n");
            }
          }, AWTEvent.ACTION_EVENT_MASK | AWTEvent.CONTAINER_EVENT_MASK |
          	 AWTEvent.MOUSE_EVENT_MASK | AWTEvent.COMPONENT_EVENT_MASK | 
              AWTEvent.WINDOW_EVENT_MASK 
               
           );


	}

	private JMenuBar createMenuBar() {

		JMenuItem newContactItem = new JMenuItem("New Contact");
		JMenuItem exitItem = new JMenuItem("Exit");

		JMenuBar menuBar = new JMenuBar();
		JMenu fileMenu = new JMenu("File");

		fileMenu.add(newContactItem);
		fileMenu.add(exitItem);
		menuBar.add(fileMenu);

		exitItem.addActionListener(this);
		newContactItem.addActionListener(new CreateContactAction());

		return menuBar;

	}

	/**
	 * Initialize the contact database with a fixed set of contacts
	 */
	private void loadContacts() {
		Contact.loadContact("James", "Bond", "(888)-007-0000");
		Contact.loadContact("Perry", "Mason", "(424)-442-2444");
		Contact.loadContact("Sam", "Little", "(112)-112-1122");
	}

	/**
	 * Refresh the list of contacts
	 */
	public void refreshList() {
		ArrayList arrayList = Contacts.getContacts();
		list.removeAll();

		String[] listData = new String[arrayList.size()];
		for (int i = 0; i < arrayList.size(); i++) {
			Contact contact = (Contact) arrayList.get(i);
			listData[i] = contact.getFirstName() + "," + contact.getLastName();
		}
		list.setListData(listData);
	}

	/**
	 * Open an "editor" (really just a JPanel) displaying information for the currently
	 * selected contact
	 */
	private void openContactEditor() {
		String contactName = list.getSelectedValue().toString();

		// Should look for panel already showing the contact's information
		// before opening a new panel

		JPanel contactEditor = new ContactEditor((Contact) Contacts.getContacts().get(list.getSelectedIndex()));
		TabCloseListener closeListener = new TabCloseListener(tabbedPane);
		tabbedPane.addTab(contactName, closeListener, contactEditor, null);
		tabbedPane.setSelectedComponent(contactEditor);
	}

	
	
	public void actionPerformed(ActionEvent e) {
	//	setVisible(false);
		dispose();
	  System.exit(0);
		
	}

}
