To run tests in an automated fashion:

* SETUP

1) Install eclipse-test framework 
(described here: http://www.eclipse.org/articles/Article-PDE-Automation/automation.html)

Let's assume your test framework is installed here: 

C:\dev\eclipse\test\eclipse-testing

1.5) Run the eclipse tests to make sure they are working... Or (at least) run the setup
ant target which unzips the eclipse installation for testing.

That is:

> runtests all

or:

> runtests setup


2) Add windowtester runtime to the eclipse-test eclipse installation.

To do this, copy the rcp-dev link to the eclipse-under-test 
(e.g., C:\dev\eclipse\test\eclipse-testing\test-eclipse\eclipse).
Supposing your target eclipse is located in 
C:\dev\eclipse\eclipse-3.1-windowtester-installed, the links can be found here:
C:\dev\eclipse\eclipse-3.1-windowtester-installed\eclipse\links.

(It's probably best to just copy the entire links directory.)

3) Copy our modified test scripts to eclipse-testing.

Copy runtests* to C:\dev\eclipse\test\eclipse-testing.

4) Export the samples plugin.

The exported plugin should look like this:

	com.windowtester.swt.samples_1.0.0/
		plugin.xml
		test.xml
		wt-samples.jar

(You can do this manually or try the export.xml ant script.)
		
5) Put exported samples plugin in the eclipse-under-test

In our case, copy com.windowtester.swt.samples_1.0.0/ to:
	
	C:\dev\eclipse\test\eclipse-testing\test-eclipse\eclipse\plugins
	
	
* RUN (phew!)

6)	Finally, we can run the tests:

	> runtests-wt -noclean wt-sample

	


