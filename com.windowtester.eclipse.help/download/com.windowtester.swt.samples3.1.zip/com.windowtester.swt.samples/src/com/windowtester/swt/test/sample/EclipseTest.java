package com.windowtester.swt.test.sample;

import junit.extensions.UITestCase;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.internal.ide.misc.ContainerSelectionGroup;

import com.windowtester.swt.IUIContext;
import com.windowtester.swt.MultipleWidgetsFoundException;
import com.windowtester.swt.WidgetLocator;
import com.windowtester.swt.WidgetNotFoundException;
import com.windowtester.swt.WidgetSearchException;
import com.windowtester.swt.condition.ICondition;
import com.windowtester.swt.condition.IHandler;
import com.windowtester.swt.condition.eclipse.WizardClosingShellHandler;
import com.windowtester.swt.condition.shell.IShellMonitor;
import com.windowtester.swt.condition.shell.ShellCondition;

/**
 * A sample UI test that excercises file and project creation in the Eclipse UI.
 * <p>
 * To run, launch using a standard Eclipse JUnit Plug-in Test Launch
 * Configuration (Run As > JUnit Plug-in Test).
 * <p>
 * Copyright (c) 2006, Instantiations, Inc.<br>
 * All Rights Reserved
 * 
 */
public class EclipseTest extends UITestCase {

	
	////////////////////////////////////////////////////////////////////
	//
	// Sample Tests
	//
	////////////////////////////////////////////////////////////////////
	
	/**
	 * A test that creates a new project and verifies that it exists 
	 * in the workspace.
	 * @throws WidgetSearchException if a widget search exception was encountered
	 */
	public void testSimpleProjectCreation() throws WidgetSearchException {
		
		String testProjectName = getClass().getName() + ".SimpleProject1";
		
		//create the project
		createSimpleProject(testProjectName);
		
		//verify it exists
		assertProjectExists(testProjectName);	
	}
	
	/**
	 * A test that creates a new Java project and verifies that it exists 
	 * in the workspace.
	 * @throws WidgetSearchException if a widget search exception was encountered
	 */
	public void testJavaProjectCreation() throws WidgetSearchException {
		
		String testProjectName = getClass().getName() + ".JavaProject1";
		
		//create the project
		createJavaProject(testProjectName);
		
		//verify it exists
		assertProjectExists(testProjectName);	
	}

	
	/**
	 * A test that creates a new file and verifies that it exists 
	 * in the workspace.
	 * @throws WidgetSearchException if a widget search exception was encountered
	 */
	public void testCreateSimpleFile() throws WidgetSearchException {
		
		String testProjectName = getClass().getName() + ".SimpleProject2";
		
		//create a host project
		createSimpleProject(testProjectName);
		//verify it exists
		assertProjectExists(testProjectName);
		
		String testFileName = "file1.txt";
		//create the file
		createSimpleFile(new Path(testProjectName), testFileName);
		//verify it exists
		assertFileExists(new Path(testProjectName + "/" + testFileName));
	}

	
	////////////////////////////////////////////////////////////////////
	//
	// Test Lifecycle
	//
	////////////////////////////////////////////////////////////////////
	
	/**
	 * @see junit.framework.TestCase#setUp()
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		/*
		 * Associate a shell handler that dismisses the "Open Associated Perspective?" modal dialog
		 * when it (un)expectedly pops up.
		 */
		IShellMonitor sm = (IShellMonitor)getUIContext().getAdapter(IShellMonitor.class);
		sm.add(new ShellCondition("Open Associated Perspective?", true), new ConfirmPerspectiveSwitchShellHandler());
		//add a handler to handle wizard closing warnings if necessary...
		sm.add(new WizardClosingShellHandler());
	}


	////////////////////////////////////////////////////////////////////
	//
	// Test Helper/Macros
	//
	////////////////////////////////////////////////////////////////////
	
	/**
	 * Create a simple project with the given name.
	 */
	public void createSimpleProject(String projectName) throws WidgetNotFoundException, MultipleWidgetsFoundException {
		
		IUIContext ui = getUIContext();
		
		//register widgets of interest
		ui.register("&Finish.button",
				new WidgetLocator(Button.class, "&Finish"));
		ui.register("text", new WidgetLocator(Text.class, new WidgetLocator(
				Composite.class)));
		ui.register("tree", new WidgetLocator(Tree.class, new WidgetLocator(
				Composite.class, new WidgetLocator(Composite.class,
						new WidgetLocator(Composite.class)))));
		ui.register("project.Next.button",
				new WidgetLocator(Button.class, "&Next >"));
		ui.register("&File.menuitem",
				new WidgetLocator(MenuItem.class, "&File"));
		ui.register("project.creation.dialog", new WidgetLocator(Shell.class,
				"New Project"));

		/*
		 * Invoke and click through the Simple Project Creation Wizard
		 */
		
		ui.click("&File.menuitem", "&New\tAlt+Shift+N/P&roject...");
		ui.waitForShellShowing("New Project");

		ui.click("tree", "Simple/Project");
		ui.click("project.Next.button");
		ui.click("text");
		ui.enterText(projectName);
		ui.click("&Finish.button");

		// wait for the project creation dialog to be dismissed
		ui.waitForShellDisposed("project.creation.dialog");
		//wait for the project to be created
		waitForProject(projectName);

	}

	/**
	 * Create a Java project with the given name.
	 */
	public void createJavaProject(String projectName) throws WidgetSearchException {
		
		IUIContext ui = getUIContext();

		//register widgets of interest
		ui.register("&Finish.button",
				new WidgetLocator(Button.class, "&Finish"));
		ui.register("tree", new WidgetLocator(Tree.class, new WidgetLocator(
				Composite.class, new WidgetLocator(Composite.class,
						new WidgetLocator(Composite.class)))));
		ui.register("&Next >.button",
				new WidgetLocator(Button.class, "&Next >"));
		ui.register("&File.menuitem",
				new WidgetLocator(MenuItem.class, "&File"));
		ui.register("project.creation.dialog", new WidgetLocator(Shell.class,
				"New Java Project"));

		/*
		 * Invoke and click through the Java Project Creation Wizard
		 */
		
		ui.click("&File.menuitem", "&New\tAlt+Shift+N/P&roject...");
		ui.waitForShellShowing("New Project");
		ui.click("tree", "Java/Java Project");
		ui.click("&Next >.button");
		ui.enterText(projectName);
		ui.click("&Finish.button");

		//wait for the project creation dialog to be dismissed
		ui.waitForShellDisposed("project.creation.dialog");
		//wait for the project to be created
		waitForProject(projectName);
	}
	
	
	/**
	 * Create a simple file with the given name.
	 */
	public void createSimpleFile(IPath fullPathToOutput, String fileName) throws WidgetSearchException {
		
		IUIContext ui = getUIContext();
		
		//register widgets of interest
		ui.register("&Finish.button",
				new WidgetLocator(Button.class, "&Finish"));
		ui.register("name.text", new WidgetLocator(Text.class,
				new WidgetLocator(Composite.class)));
		ui.register("tree", new WidgetLocator(Tree.class, new WidgetLocator(
				Composite.class, new WidgetLocator(Composite.class,
						new WidgetLocator(Composite.class)))));
		ui.register("&Next >.button",
				new WidgetLocator(Button.class, "&Next >"));
		ui.register("&File.menuitem",
				new WidgetLocator(MenuItem.class, "&File"));
		ui.register("text.location", new WidgetLocator(Text.class,
				new WidgetLocator(ContainerSelectionGroup.class)));

		/*
		 * Invoke and click through the File Creation Wizard
		 */
		
		ui.click("&File.menuitem", "&New\tAlt+Shift+N/&Other...\tCtrl+N");
		ui.waitForShellShowing("New");
		ui.click("tree", "Simple/File");
		ui.click("&Next >.button");

		ui.doubleClick("text.location");
		ui.enterText(fullPathToOutput.toPortableString());

		ui.doubleClick("text");
		ui.enterText(fileName);
		ui.click("&Finish.button");

		//wait for the file to show up in the file system
		waitForFile(fullPathToOutput.append(new Path(fileName)));
	}

	
	////////////////////////////////////////////////////////////////////
	//
	// Assertion Helpers
	//
	////////////////////////////////////////////////////////////////////
	
	/**
	 * Assert that a file exists at the given path.
	 */
	public static void assertFileExists(Path fullFilePath) {
        IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
        IFile file = root.getFile(fullFilePath);
        assertTrue(file.exists());
	}
	/**
	 * Assert that a folder exists at the given path.
	 */
	public static void assertFolderExists(Path fullFilePath) {
        IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
        IFolder folder = root.getFolder(fullFilePath);
        assertTrue(folder.exists());
	}
	
	/**
	 * Assert that a project exists with the given name.
	 */
	public static void assertProjectExists(String projectName) {
        IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
        IProject project = root.getProject(projectName);
        assertTrue(project.exists());
	}	
	
	
	////////////////////////////////////////////////////////////////////
	//
	// Helper Conditions
	//
	////////////////////////////////////////////////////////////////////
	
	/**
	 * A condition that tests for widget disposal.
	 */
	public static class WidgetDisposedCondition implements ICondition {
	    private Widget _widget;

	    public WidgetDisposedCondition(Widget widget) {
	        assertNotNull(widget);
	        _widget = widget;
	    }

	    /**
	     * @see com.windowtester.swt.condition.ICondition#test()
	     */
	    public boolean test() {
	        return _widget.isDisposed();
	    }
	}
	
	/**
	 * A condition that tests for project existence.
	 */	
	public static class ProjectExistsCondition implements ICondition {
	    private final IProject _iproject;
	    private final boolean _exists;

	    public ProjectExistsCondition(String projectName, boolean exists) {
	        assertNotNull(projectName);
	        
	        IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
	        assertNotNull(root);
	        
	        _iproject = root.getProject(projectName);
	        _exists = exists;
	    }
	    
		public ProjectExistsCondition(IProject project, boolean exists) {
	        assertNotNull(project);
	        
	        _iproject = project;
	        _exists = exists;
	    }

	    /**
	     * @see com.windowtester.swt.condition.ICondition#test()
	     */
	    public boolean test() {
	        return _exists == _iproject.exists();
	    }
	}

	/**
	 * A condition that tests for file existence.
	 */	
	public static class FileExistsCondition implements ICondition {
	    private final IPath _path;
	    private final boolean _exists;

	    public FileExistsCondition(IPath fullFilePath, boolean exists) {
	        _exists = exists;
	        
	        IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
	        IFile file = root.getFile(fullFilePath);
	        _path = file.getLocation();
	    }
	    
	    /**
	     * @see com.windowtester.swt.condition.ICondition#test()
	     */
	    public boolean test() {
	        return _path.toFile().exists() == _exists;
	    }
	}
	
	/**
	 * A condition that tests for folder existence.
	 */	
	public static class FolderExistsCondition implements ICondition {
	    private final IPath _path;
	    private final boolean _exists;

	    public FolderExistsCondition(IPath fullFilePath, boolean exists) {
	        _exists = exists;
	        
	        IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
	        IFolder folder = root.getFolder(fullFilePath);
	        _path = folder.getLocation();
	    }
	    
	    /**
	     * @see com.windowtester.swt.condition.ICondition#test()
	     */
	    public boolean test() {
	        return _path.toFile().exists() == _exists;
	    }
	}
	
	
	////////////////////////////////////////////////////////////////////
	//
	// Helper Shell Handlers
	//
	////////////////////////////////////////////////////////////////////
	
	/**
	 * A shell handler that dismisses the "Confirm Perspective Switch Shell" by
	 * clicking the "no" button.
	 */
	public static class ConfirmPerspectiveSwitchShellHandler implements IHandler {

		/**
		 * @see com.windowtester.swt.condition.IHandler#handle(com.windowtester.swt.IUIContext)
		 */
		public void handle(IUIContext ui) {
		        
		        ui.register("button.no", new WidgetLocator(Button.class, "&No"));
		     
		        try {
		            ui.click("button.no");
		        }
		        catch(WidgetSearchException e) {
		            fail(e.getLocalizedMessage());
		        }
		}
			
	}
	
	
	////////////////////////////////////////////////////////////////////
	//
	// Wait for Condition Helpers
	//
	////////////////////////////////////////////////////////////////////
	
	/**
	 * Wait for a project with the given name to show up in the file system.
	 */
	public void waitForProject(String projectName) {
		getUIContext().wait(new ProjectExistsCondition(projectName, true), 45000,
				2500);
	}

	/**
	 * Wait for the widget with the given handle to be disposed.
	 */
	public void waitForWidgetDisposed(String widgetHandle) {
		try {
			IUIContext ui = getUIContext();
			Widget shell = ui.find(widgetHandle);
			assertNotNull(shell);
			ui.wait(new WidgetDisposedCondition(shell));
		} catch (WidgetNotFoundException e) {
			//actually, this is ok: the widget may *already* be disposed
		} catch (MultipleWidgetsFoundException e) {
			fail(e.getMessage());
		}
	}

	/**
	 * Wait for the for a file at the given path to exist.
	 */	
    public void waitForFile(IPath fullFilePath) {
        getUIContext().wait(new FileExistsCondition(fullFilePath, true));
    }

	/**
	 * Wait for the for a folder at the given path to exist.
	 */	
    public void waitForFolder(IPath fullFilePath) {
        getUIContext().wait(new FolderExistsCondition(fullFilePath, true));
    }
    
    
}
